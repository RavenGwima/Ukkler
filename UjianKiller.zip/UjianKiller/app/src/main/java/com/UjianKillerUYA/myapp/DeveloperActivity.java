package com.UjianKillerUYA.myapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class DeveloperActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_developer);

        // Jika ada tombol kembali atau aksi lain di halaman developer bisa diatur di sini
    }
}
