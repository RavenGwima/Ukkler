package com.UjianKillerUYA.myapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.net.Uri;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class MainActivity extends Activity {

    private LinearLayout btnScan;
    private LinearLayout btnDevMenu;
    private TextView titleApp;
    private LinearLayout containerMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        // Menghubungkan komponen dengan ID
        titleApp = (TextView) findViewById(R.id.titleApp); // Pastikan TextView judul di main.xml punya id ini
        containerMenu = (LinearLayout) findViewById(R.id.containerMenu); // Layout pembungkus 2 kotak
        btnScan = (LinearLayout) findViewById(R.id.btnScan);
        btnDevMenu = (LinearLayout) findViewById(R.id.btnDevMenu);

        // Memuat animasi dari folder anim
        Animation slideUp = AnimationUtils.loadAnimation(this, R.anim.slide_up_fade);

        // Menjalankan animasi secara berurutan/bersamaan saat activity dimuat
        if (titleApp != null) titleApp.startAnimation(slideUp);
        if (containerMenu != null) containerMenu.startAnimation(slideUp);

        // Logika Klik Scan QR
        btnScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                IntentIntegrator scanner = new IntentIntegrator(MainActivity.this);
                scanner.setPrompt("Arahkan kamera ke QR Code");
                scanner.setBeepEnabled(true);
                scanner.setOrientationLocked(false);
                scanner.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);
                scanner.initiateScan();
            }
        });

        // Logika Klik Developer Menu
        btnDevMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, DeveloperActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() == null) {
                Toast.makeText(this, "Scan dibatalkan", Toast.LENGTH_SHORT).show();
            } else {
                String contents = result.getContents();
                Uri uri = Uri.parse(contents);
                String scheme = uri.getScheme();

                if (uri.getHost() != null && 
                    ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme))) {
                    
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, uri);
                    if (browserIntent.resolveActivity(getPackageManager()) != null) {
                        startActivity(browserIntent);
                    } else {
                        Toast.makeText(this, "Browser tidak ditemukan", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(this, "QR bukan tautan web yang valid", Toast.LENGTH_LONG).show();
                }
            }
        }
    }
}
